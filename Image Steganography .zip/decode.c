#include <stdio.h>
#include "decode.h"
#include "types.h"
#include "common.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
int extn_file_size, i;
int secret_file_size;
/*function definition to read and validate decode*/
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
	//Checking wether source image is .bmp or not and store
	if(strcmp(strstr(argv[2], "."), ".bmp") == 0)
	{
		decInfo -> stego_image_fname = argv[2];

	//Check if arguement 3 had passed any file if not creat secret file name and store and return success
		if(argv[3] == NULL)
		{
			strcpy(decInfo -> secret_fname_default, "secret_retrive");
			return e_success;
		}
		else
		{
	//if it is passed then store to variable and return success
			strcpy(decInfo -> secret_fname_default, argv[3]);
			return e_success;
		}
	}
	else
	{
	//else return failure
		fprintf(stderr, "Error: Stego image %s formate should be .bmp\n", argv[2]);
		sleep(1);
		return e_failure;                   
	}
}

/*function definition to do_decoding function which performs decoding*/
Status do_decoding(DecodeInfo *decInfo)
{
	/*Step 1: Call open_files
	  Step 2: Check return value is success or not
	  Step 3: If true -> print some messgae, Goto Step 4.
	 			:else -> print error msg, return e_failure*/
	if(open_files_decode(decInfo) == e_success)
	{
		printf("INFO: Open files for decoding is successfull\n");
		sleep(1);
		
	/*Step 4: Call skip_bmp_header to skip first 54 bits and point to 55th byte
	  Step 5: Check return value is success or not
	  Step 6: If yes -> print some message, Goto Step 7
	 			:else -> print error msg, return e_failure*/
		if(skip_bmp_header(decInfo -> fptr_stego_image) == e_success)
		{
			printf("INFO: Skip bmp header is successfull\n");
			sleep(1);
			
	/*Step 7: Call decode_magic_string
	  Step 8: Check return value is success or not
	  Step 9: If yes -> print some message, Goto Step 10
	 			:else -> print error msg, return e_failure*/
			printf("INFO: Decoding Magic string\n");
			char magic_str[] = MAGIC_STRING;
			if(decode_magic_string(magic_str,decInfo) == e_success)
			{
				printf("INFO: Done\n");
				sleep(1);
				
	/*Step 10: Call decode_file_extn_size
	  Step 11: Check return value is success or not
	  Step 12: If yes -> print some message, Goto Step 13
	 			:else -> print error msg, return e_failure*/
				printf("INFO: Decoding file extention size\n");
				if(decode_file_extn_size(decInfo) == e_success)
				{
					printf("INFO: Done\n");
					sleep(1);
					
	/*Step 13: Call decode_secret_file_extn
	  Step 14: Check return value is success or not
	  Step 15: If yes -> print some message, Goto Step 16
	 			:else -> print error msg, return e_failure*/
					printf("INFO: Decoding the secret file extension\n");
					if(decode_secret_file_extn(extn_file_size, decInfo -> secret_extn_fname, decInfo -> fptr_stego_image) == e_success)
					{
						printf("INFO: Done\n");
						sleep(1);
						
	/*Step 16: decode_secret_file
	  Step 17: Check return value is success or not
	  Step 18: If yes -> print some message, Goto Step 19
	 			:else -> print error msg, return e_failure*/
						printf("INFO: Open secret file\n");
						if(open_secret_file(decInfo -> secret_extn_fname, decInfo -> secret_fname_default, &decInfo -> secret_fname, decInfo -> fptr_secret) == e_success)
						{
							printf("INFO: Done\n");
							sleep(1);
							
	/*Step 19: Call decode_secret_file_size
	  Step 20: Check return value is success or not
	  Step 21: If yes -> print some message, Goto Step 22
	 			:else -> print error msg, return e_failure*/
							printf("INFO: Decoding secret file size\n");
							if(decode_secret_file_size(decInfo) == e_success)
							{
								printf("INFO: Done\n");
								sleep(1);
								
	/*Step 22: Call decode_secret_file_data
	  Step 23: Check return value is success or not
	  Step 24: If yes -> print some message, return e_success 
	 			:else -> print error msg, return e_failure*/
								printf("INFO: Decoding secret file data\n");
								if(decode_secret_file_data(decInfo -> fptr_stego_image, decInfo -> fptr_secret, &decInfo -> secret_fname) == e_success)
								{
									printf("INFO: Done\n");
									return e_success;
								}
								else
								{
									printf("INFO : Decode secret file data is unsuccessfull\n");
									return e_failure;
								}
							}
							else
							{
								printf("INFO : Decode secret file size is unsuccessfull\n");
								return e_failure;
							}
						}
						else
						{
							printf("INFO : Secret file open is unsuccessfull\n");
							return e_failure;
						}
					}
					else
					{
						printf("INFO : decode secret file extention is unsuccessfull\n");
						return e_failure;
					}
			    }
				else
				{
					printf("INFO : decode file extention size is unsuccessfull\n");
					return e_failure;
				}
			}
			else
			{
				printf("INFO : Magic string is unsuccessfull\n");
				return e_failure;
			}
		}
		else
		{
			
			printf("INFO : skip bmp header is unsuccessfull\n");
			return e_failure;
		}
	}	
	else
	{
		printf("INFO : Open files for decoding is unsuccessfull\n");
		return e_failure;
	}
}

/*function definition to access program need to open files and get file pointers for input and output files*/
Status open_files_decode(DecodeInfo *decInfo)
{
	// source file (stego.bmp)
	decInfo -> fptr_stego_image = fopen(decInfo -> stego_image_fname, "r");
	
	//Do Error Handling
	if(decInfo -> fptr_stego_image == NULL)
	{
		perror("fopen");
		fprintf(stderr, "ERROR : Unable to open files %s\n", decInfo -> stego_image_fname);
		return e_failure;
	}
	else
	{
		printf("INFO: Opened %s\n", decInfo -> stego_image_fname);
		sleep(1);
		return e_success;
	}
}

/*Function definition skip header , seek pointer to 54th position*/
Status skip_bmp_header(FILE *fptr_stego_image){
// using fseek point header to 54th poition
	fseek(fptr_stego_image, 54, SEEK_SET);
	return e_success;
}

/*function definition to decode or store the magic string*/
Status decode_magic_string(char *magic_string, DecodeInfo *decInfo)
{		

	int size = strlen(MAGIC_STRING);   //store length of magic string
	char data[size];

	//call decode_image_to data
	if(decode_image_to_data(size, data, decInfo -> fptr_stego_image) == e_success)
	{
		if(!strcmp(data, magic_string))
		{
			return e_success;
		}
		else
		{
			printf("Magic String is not similar\n");
			return e_failure;
		}
	}
	else
	{
		return e_failure;
	}
	
}


/*function definition to decode output file extention size*/
Status decode_file_extn_size(DecodeInfo *decInfo)
{
	char buf[32];

	//read 32 bytes of data from source image to buffer array
	fread(buf, 32, 1, decInfo->fptr_stego_image);
	
	//call decode_lsb_to_size and store to variable
	extn_file_size = decode_lsb_to_size(buf);
	return e_success;
}

/*function definition to decode secret file extention*/
Status decode_secret_file_extn(int extn_file_size, char *secret_extn_fname, FILE *fptr_stego_image)
{
	decode_image_to_data(extn_file_size, secret_extn_fname, fptr_stego_image);
	return e_success;
}

/*function definition to open secret file*/
Status open_secret_file(char *secret_extn_fname, char *secret_fname_default, char **secret_fname, FILE *fptr_secret)
{
	//allocate dynamically memeory of secret file size to secret_fname
	*secret_fname = calloc(strlen(secret_fname_default)+strlen(secret_extn_fname)+1,sizeof(char));

	//to store null charater
	(*secret_fname)[strlen(secret_fname_default)+ strlen(secret_extn_fname)] = '\0'; 

	//concatinate file and extention(.txt)
	strcpy(*secret_fname , strcat(secret_fname_default, secret_extn_fname));  //concat file and exten (.txt)
	return e_success;               //else return success
}

/*function defintion to decode secret file size*/
Status decode_secret_file_size(DecodeInfo *decInfo)
{
	char buffer[32];

	//read 32 bytes of data from source image to buffer array
	fread(buffer, 32, 1, decInfo -> fptr_stego_image);

	//call decode_lsb_to_size and store to variable
	secret_file_size = decode_lsb_to_size(buffer);

//	printf("file2 = %d\n", secret_file_size);
	return e_success;
}

/*function defintion to decode secret file data*/
Status decode_secret_file_data(FILE *fptr_stego_image, FILE *fptr_secret, char **secret_fname)
{
	char buff[secret_file_size];
	int size = secret_file_size;

	//call decode_image_to_data 
	if(decode_image_to_data(size, buff, fptr_stego_image) == e_success)
	{
		//open the file of secret_fname in write mode and check file is null or not
		fptr_secret = fopen(*secret_fname, "w");
		printf("INFO: Opened %s\n", *secret_fname);
		sleep(1);
		if( fptr_secret == NULL )
		{
			perror("fopen");
			fprintf(stderr, "ERROR : Unable to open file. %s\n", *secret_fname);
			printf("NULL\n");
		}

		//write data from buffer to fptr_secret [destination file]
		fwrite(buff , secret_file_size, 1, fptr_secret);
		printf("INFO: Data copied\n");
		sleep(1);
		fclose(fptr_secret);
		return e_success;
	}
}

/*function definition to decode image to data*/
Status decode_image_to_data(int size, char *data, FILE *fptr_stego_image)
{
	char arr[8];                        //buffer array
	for(int i = 0; i < size; i++)
	{
		//read 8 bytes of data, store to buffer array from source image
		fread(arr, 8, 1, fptr_stego_image);

		//call decode_lsb_byte
		if(decode_lsb_to_byte(arr, &data[i]) != e_success)
		{
			printf("lsb to data is failure");
			return e_failure;
		}
	}
	data[size] = '\0';
	return e_success;
}

/*function defintion to decoding lsb to byte*/
Status decode_lsb_to_byte(char *image_buffer, char *data)
{
	 *data = 0;
   //get bits from image_buffer
   //add to the data 
	 //repeat for 8 times
	for(int i = 7; i >= 0; i--)
	{
		*data = (*data | ((image_buffer[7 - i] & 1) << i));
	}
	return e_success;
}

/*decode lsb to size*/
Status decode_lsb_to_size(char *image_buffer)
{
	int size = 0;
	//get bits from image_bufferr
	//and add it to the size 
	//repeat for 32 times 
	//return size
	for(int i = 31; i >= 0 ; i--)
	{
		size = size | ((image_buffer[31 -i] & 1) << i);
	}
	return size;
}
