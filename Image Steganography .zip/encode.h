#ifndef ENCODE_H
#define ENCODE_H

#include "types.h" // Contains user defined types

/* 
 * Structure to store information required for
 * encoding secret file to source Image
 * Info about output and intermediate data is
 * also stored
 */

#define MAX_SECRET_BUF_SIZE 1
#define MAX_IMAGE_BUF_SIZE (MAX_SECRET_BUF_SIZE * 8)
#define MAX_FILE_SUFFIX 4

typedef struct _EncodeInfo
{
    /* Source Image info */
    char *src_image_fname;       //source image file name     
    FILE *fptr_src_image;        //sorce image address store in file pointer
    uint image_capacity;         //store size of .bmp file
   // uint bits_per_pixel;         //
    //char image_data[MAX_IMAGE_BUF_SIZE]; 

    /* Secret File Info */
    char *secret_fname;          //base address of secret file store in this pointer
    FILE *fptr_secret;          //file pointer for secret file
    char extn_secret_file[MAX_FILE_SUFFIX+1];    //to store extension of secret file .txt
    //char secret_data[MAX_SECRET_BUF_SIZE];    
    int size_secret_file;       //size of secret file

    /* Stego Image Info */      //output file
    char *stego_image_fname;    //destination image file name string address
    FILE *fptr_stego_image;      //file pointer for destination image

} EncodeInfo;


/* Encoding function prototype */

/* Check operation type */
OperationType check_operation_type(char *argv[]);

/* Read and validate Encode args from argv */    // to check .bmp and 2nd file ,3rd file user create file -> test -> append test.BMP 
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo); //to store it into file 

/* Perform the encoding */
Status do_encoding(EncodeInfo *encInfo);

/* Get File pointers for i/p and o/p files */
Status open_files(EncodeInfo *encInfo);

/* check capacity */
Status check_capacity(EncodeInfo *encInfo);

/* Get image size */
uint get_image_size_for_bmp(FILE *fptr_image);

/* Get file size */
uint get_file_size(FILE *fptr);

/* Copy bmp image header */
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image);

/* Store Magic String */
Status encode_magic_string(char *magic_string, EncodeInfo *encInfo);

/*  Encode secret file extention size*/
Status encode_file_extn_size(int extn_size, FILE *fptr_src_image, FILE *fptr_stego_image);

/* Encode secret file extenstion */
Status encode_secret_file_extn(char *file_extn, FILE *fptr_src_image, FILE *fptr_stego_image); // get extension data and size

/* Encode secret file size */
Status encode_secret_file_size(int file_size, FILE *fptr_src_image, FILE *fptr_stego_image);

/* Encode secret file data*/
Status encode_secret_file_data(EncodeInfo *encInfo);

/* Encode function, which does the real encoding */
Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image);

/* Encode a byte into LSB of image data array */
Status encode_byte_to_lsb(char data, char *image_buffer);

/*encode the integer value*/
Status encode_size_to_lsb(int size, char *image_buffer);

/* Copy remaining image bytes from src to stego image after encoding */
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest);

#endif
