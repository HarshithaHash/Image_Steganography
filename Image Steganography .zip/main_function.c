/* Documentation
NAME            : Harshitha V
DATE            : 16/01/2024
DESCRIPTION     : C project - Digital LSB Image Steganography.
*/
#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "decode.h"
#include <unistd.h>

int main(int argc, char *argv[])
{
	//declairing structure variables
	EncodeInfo encInfo;                                              
    DecodeInfo decInfo;

    //declaring the variable
	int res;

	//call type = check_operation_type(argv)
    if(argc >= 3)
	{
		res	= check_operation_type(argv);    //call the function to check operation and store to variable
		if(res == e_unsupported)             //check if returned value equal to e_unsupported
		{
			printf("INFO: Invalid with the usage\n");  //if true then print invalid and terminate
			sleep(1);
			return e_failure;
		}
		else if(res == e_encode)             //else if check returned value equal to e_encode (-e)
		{
			printf("INFO: selected encoding\n");  //if true call read and validate function to check whether the files are present or not
			sleep(1);
			if(read_and_validate_encode_args(argv, &encInfo) == e_success) //check the returned is success or not
			{
				printf("INFO: read and validation is successfull\n");  //if success call do encoding function here actual encoding process is done
				sleep(1);
				printf("INFO: ##Encoding Procedure Started##\n");
				sleep(1);
				if(do_encoding(&encInfo) == e_success)    //check if the encode is return success or not 
				{
					printf("INFO: ##Encoding Done Successfully##\n");  //if true print success
					sleep(1);
				}
				else
				{
					printf("INFO: Encode is failure\n");   //if print failure and terminate the program
					sleep(1);
					return e_failure;
				}
			}
		}	
		else if(res == e_decode)             //else if check return value is decode (-d) or not
		{
			printf("INFO: selected decoding\n");
			sleep(1);
			if(read_and_validate_decode_args(argv, &decInfo) == e_success)  //if true call read and validate function to check whether the files are present or not check with returned is success or not
			{
				printf("INFO: Read and validate is successfull\n");    
				sleep(1);
				printf("INFO: ##Decoding Procedure Started##\n");
				if(do_decoding(&decInfo) == e_success)         //if success call the decode function where actual decoding process is done and if the decode if success or not
				{
					printf("INFO: ##Encoding Done Successfully##\n"); //if succcess print decode sucessfull
					sleep(1);
				}
				else
				{
					printf("INFO: Decoding if failure\n");     //else print failure and terminate the program
					sleep(1);
					return e_failure;
				}

			}
		}
	}
	return 0;
}

OperationType check_operation_type(char *argv[])
{
	//check argv[1] is "-e" or not using string compare
	if(argv[1] != NULL)
	{
		if(strcmp(argv[1],"-e") == 0) 
		{
			return e_encode;      //if true then return e_encode
		}
	//check argv[1] is "-d" or not using string compare
    	else if(strcmp(argv[1], "-d") == 0)
		{
			return e_decode;      //if true then return e_decode
		}
	    else
		{
			return e_unsupported; //else if it is not either -e or -d then return un_supported
		}
	}
	else
	{
		return e_unsupported;    //if user didn't pass any arguement then return unsupported
	}
}
