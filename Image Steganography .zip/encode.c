#include <stdio.h>                                    //preprocessor directories
#include "encode.h"
#include "types.h"
#include <unistd.h>

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */

#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "common.h"

/* get image size*/
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);        

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);
	sleep(1);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);
	sleep(1);

    // Return image capacity
    return width * height * 3;
}

/* get file size */
uint get_file_size(FILE *fptr)
{
	fseek(fptr, 0, SEEK_END);    //it will point curssor to end of file and
	int len = ftell(fptr);       //ftell()  wil point to the position and store to variable  
	return len;                  //return len
}
/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */

/*read and validate encode*/
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
	//step 1:check argv[2] is ".bmp" or not
	//		: if yes -> store argv[2] into src_image_fname(structure member), goto step2
	//      : else -> return e_failure
	if(strcmp(strstr(argv[2], "."), ".bmp") == 0)
	{
		encInfo -> src_image_fname = argv[2];
	}
	else
	{
		fprintf(stderr,"Error: Source image %s format should be .bmp\n", argv[2]);
		sleep(1);
		return e_failure;
	}

	//step 2:check argv[3] is ".txt" or not
	//		: if yes -> store argv[3] into secret_fname(structure member), goto step3
	//      : else -> return e_failure
	if(strcmp(strcpy(encInfo -> extn_secret_file, strstr(argv[3], ".")), ".txt") || strcmp(strcpy(encInfo -> extn_secret_file, strstr(argv[3], ".")), ".sh") || strcmp(strcpy(encInfo -> extn_secret_file, strstr(argv[3], ".")), ".c") == 0)
	{
		
		encInfo -> secret_fname	= argv[3];
		encInfo -> extn_secret_file[4] = '\0';
	}
	else
	{
		fprintf(stderr, "Error: Secret file %s format should be .txt or .c or .sh\n", argv[3]);
		sleep(1);
		return e_failure;
	}
	//step 3:check argv[4] is passed or not
	//      : if yes -> check argv[4] is ".bmp" or not
	//			:if yes -> Store argv[4] into stego_image_fname(structure member), goto step4
	if(argv[4] == NULL)
	{
		encInfo -> stego_image_fname = "stego_img.bmp";
	}
	else
	{
		if(strcmp(strstr(argv[4], "."), ".bmp") == 0)
		{
			encInfo -> stego_image_fname = argv[4];
		}
		else
		{
			encInfo -> stego_image_fname = "stego_img.bmp";
		}
	}
	//step 4: Return e_success
	return e_success;
}

/* do_encode function which performs encoding */
Status do_encoding(EncodeInfo *encInfo)
{
	/*Step 1: Call open_files
	  Step 2: Check return value is success or not
	  Step 3: If true -> print some messgae, Goto Step 4.
	 			:else -> print error msg, return e_failure*/
	if(open_files(encInfo) == e_success)
	{
		printf("INFO: Open file is successfull\n");
		sleep(1);

	/*Step 4: Call check_capacity
	  Step 5: Check return value is success or not
	  Step 6: If yes -> print some message, Goto Step 7
	 			:else -> print error msg, return e_failure*/
		printf("INFO: Checking for beautifu.bmp capacity to handle secret.txt\n");
		if(check_capacity(encInfo) == e_success)
		{
			printf("INFO: Check capacity is Done. Found OK\n");
        	sleep(1);

	  /*Step 7: Call copy_bmp_header
	  Step 8: Check return value is success or not
	  Step 9: If yes -> print some message, Goto Step 10
	 			:else -> print error msg, return e_failure*/
			printf("INFO: Copying Image Header\n");
			if(copy_bmp_header(encInfo -> fptr_src_image, encInfo -> fptr_stego_image) == e_success)
			{
				printf("INFO: Done\n");
				sleep(1);

	/*Step 10: Call encode_magic_string
	  Step 11: Check return value is success or not
	  Step 12: If yes -> print some message, Goto Step 13
	 			:else -> print error msg, return e_failure*/
				printf("INFO: Encoding Magic String Signature\n");
				char magic_str[] = MAGIC_STRING;
				if(encode_magic_string(magic_str, encInfo) == e_success)
				{
					printf("INFO: Done\n");
					sleep(1);

	/*Step 13: Call encode_file_extn_size
	  Step 14: Check return value is success or not
	  Step 15: If yes -> print some message, Goto Step 16
	 			:else -> print error msg, return e_failure*/
					printf("INFO: Encoding File Extension Size\n");
					if(encode_file_extn_size(strlen(encInfo -> extn_secret_file), encInfo -> fptr_src_image, encInfo -> fptr_stego_image) == e_success)
					{
						printf("INFO: Done\n");
		    			sleep(1);

	/*Step 16: encode_secret_file_extn
	  Step 17: Check return value is success or not
	  Step 18: If yes -> print some message, Goto Step 19
	 			:else -> print error msg, return e_failure*/
						printf("INFO: Encoding %s File Extenstion\n", encInfo -> secret_fname);
						if(encode_secret_file_extn(encInfo -> extn_secret_file, encInfo -> fptr_src_image, encInfo -> fptr_stego_image) == e_success)
						{
							printf("INFO: Done\n");
							sleep(1);

	/*Step 19: Call encode_secret_file_size
	  Step 20: Check return value is success or not
	  Step 21: If yes -> print some message, Goto Step 22
	 			:else -> print error msg, return e_failure*/
							printf("INFO: Encoding %s File size\n", encInfo -> secret_fname);
							if(encode_secret_file_size(encInfo -> size_secret_file, encInfo -> fptr_src_image, encInfo -> fptr_stego_image) == e_success)
							{
								printf("INFO: Done\n");
								sleep(1);

	/*Step 22: Call encode_secret_file_data
	  Step 23: Check return value is success or not
	  Step 24: If yes -> print some message, Goto Step 25 
	 			:else -> print error msg, return e_failure*/
								printf("INFO: Encoding %s File Data\n", encInfo -> secret_fname);
								if(encode_secret_file_data(encInfo) == e_success)
								{
									printf("INFO: Done\n");
									sleep(1);

	/*Step 25: Call copy_remaining_img_data
	  Step 26: Check return value is success or not
	  Step 27: If yes -> print some message, return e_success
	 			:else -> print error msg, return e_failure*/
									printf("INFO: Copying Left Over Data\n");
									if(copy_remaining_img_data(encInfo -> fptr_src_image, encInfo -> fptr_stego_image) == e_success)
									{
										printf("INFO : Done\n");
										sleep(1);
										return e_success;
									}
									else
									{
										printf("INFO : remaining bytes did not copied successfully\n");
										sleep(1);
										return e_failure;
									}
								}
					            else
								{

									printf("INFO: encoded scret file data not done successfully\n");
									sleep(1);
									return e_failure;
								}
                            }
							else
							{
								printf("INFO: encoded secret file size successfully\n");
								sleep(1);
								return e_failure;
							}
					}
						else
						{
							printf("INFO: encode file extention data is not done successfully\n");
							sleep(1);
							return e_failure;
						}
					}
					else
					{
						printf("INFO: encode file extention size is not done successfully\n");
						sleep(1);
						return e_failure;
					}
				}
				else
				{
					printf("INFO: Magic String is not successfully done\n");
					sleep(1);
					return e_failure;
				}
			}
			else
			{
				printf("INFO: bmp header failur\n");
				sleep(1);
				return e_failure;
			}
		}
		else
		{
			printf("INFO: check capacity not done successfully\n");
			sleep(1);
			return e_failure;
		}
	}
	else
	{
		printf("INFO: open_file not done successfully.\n");
		sleep(1);
		return e_failure;
	}
}
/*function definition to open files*/
/*we have strings to access program we need to open files and get file pointers for i/p and o/p files */
Status open_files(EncodeInfo *encInfo)
{
   // Src Image file 
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    	return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

    	return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling.
    if (encInfo->fptr_stego_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

    	return e_failure;
    }

    // No failure return e_success
    return e_success;
}

/* function definition to check capacity*/
Status check_capacity(EncodeInfo *encInfo)
{
	//finding the source image size
	encInfo -> image_capacity = get_image_size_for_bmp(encInfo -> fptr_src_image);

	//finding the secret file size
	encInfo -> size_secret_file = get_file_size(encInfo->fptr_secret);

	//check image capacity > Calculation(header + (magic sring length + size of extention value(int) + extention data size + size of secret file(integer value) + secret file size) * 8)
	if(encInfo -> image_capacity > 54 + (strlen(MAGIC_STRING) + sizeof(int) + strlen(encInfo->secret_fname) + sizeof(int) + encInfo -> size_secret_file) * 8)
	{
		return e_success;            //if true return success
	}
	else
	{
		return e_failure;
	}
}
 /*function definition to copy bmp header to destination file*/
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
	char arr[54];
	// Move the file_pointer to 1st position
	rewind(fptr_src_image);

	//Read 54 bytes of data from src_image and store into buffer
	fread(arr, 54, 1, fptr_src_image);

	//Write 54 bytes of data into strgo_imag from buffer
  	fwrite(arr, 54, 1, fptr_dest_image);
	return e_success;	
}

/* function definition to encode or store the magic string*/
Status encode_magic_string(char *magic_string, EncodeInfo *encInfo)
{
	encode_data_to_image(magic_string, strlen(MAGIC_STRING), encInfo -> fptr_src_image, encInfo -> fptr_stego_image);
	return e_success;
	//CHECK WHERE THE POINTER IS POINTING IN IMAGE
    printf("pointer is pointing %ld in image\n", ftell(encInfo -> fptr_src_image));
} 

/*function definition to encode file extension size*/
Status encode_file_extn_size(int extn_size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
	char buff[32];

	//read 32bytes of data from src_image and store into buff
	fread(buff , 32, 1, fptr_src_image);

	//call the function
	encode_size_to_lsb(extn_size, buff);

	//wrtie buffer into stego_image
	fwrite(buff, 32, 1, fptr_stego_image);
	return e_success;
}

/*Encode secret file extenstion*/
Status encode_secret_file_extn(char *file_extn, FILE *fptr_src_image, FILE *fptr_stego_image)
{
	//call encode_data_to_image()
	encode_data_to_image(file_extn ,strlen(file_extn), fptr_src_image, fptr_stego_image);
	return e_success;
}

/*function definition to encode secret file size*/
Status encode_secret_file_size(int file_size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
	char buff[32];

	//read 32bytes of data from src_image and store to buffer array
	fread(buff, 32, 1, fptr_src_image);

	//call the function
	encode_size_to_lsb(file_size, buff);

	//write buffer into stego_image
	fwrite(buff, 32, 1, fptr_stego_image);
	return e_success;
}

/* function definition to Encode secret file data*/
Status encode_secret_file_data(EncodeInfo *encInfo)
{
	char secret_data[encInfo -> size_secret_file];
	//rewind fptr_secret
	rewind(encInfo -> fptr_secret);
	//read size_secret_file data from fptr_secret, stored into secret_data[arr]
	fread(secret_data, encInfo -> size_secret_file, 1, encInfo -> fptr_secret);
	//call the function encode_data_to_image
	encode_data_to_image(secret_data, encInfo -> size_secret_file, encInfo -> fptr_src_image, encInfo -> fptr_stego_image);
	//write secret_file_size data from secret_data to stego_image
/*	rewind(encInfo -> fptr_secret);
	fread(secret_data, encInfo -> size_secret_file, 1, encInfo -> fptr_secret);
	encode_data_to_image(secret_data, encInfo -> size_secret_file, encInfo -> fptr_src_image, encInfo ->fptr_stego_image);*/
	return e_success;
}

/*function definition to Copy_remaininging image bytes from source to stego image after encoding*/
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
	int ch;
	while(fread(&ch, 1, 1, fptr_src) > 0)
	{
		fwrite(&ch, 1, 1, fptr_dest);
	}
	return e_success;
}
/*function definition to encode data to image encoding*/
Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
	char arr[8];                                  //buffer array
	for(int i = 0; i < size; i++)
	{
		//read 8 byte of data, Store into buffer array
		fread(arr, 8, 1, fptr_src_image);

		//call the encode_byte_to_lsb
		encode_byte_to_lsb(data[i], arr);
		
		//write data from buffer to destination image that is setgo file image
		fwrite(arr, 8, 1, fptr_stego_image);
	}
	return e_success;
}

/*function definition to encode byte to lsb*/
Status encode_byte_to_lsb(char data, char *image_buffer)
{
	//get a bit from data
	//clear LSB bit from buffer[0]
	//replace the got bit to buffer[0]
	//repeat for 8 times
	for(int i = 0; i < 8; i++)
	{
		image_buffer[i] = (image_buffer[i] &(~(1))) | ((data >> (7 - i)) & 1);
	}
	return e_success;
}

/*function definition to encode size to lsb*/
Status encode_size_to_lsb(int size, char *image_buffer)
{
	//encode process for 32 times
	for(int i = 0; i < 32; i++)
	{
		image_buffer[i] = (image_buffer[i] &(~(1))) | ((size >> (31 - i)) & 1);
	}
	return e_success;
}

